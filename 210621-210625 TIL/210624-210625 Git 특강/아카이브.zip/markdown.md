![Image](https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRRfDtBfKwqy-2X3dZcUNZIuwLxD7s1sZjO4Yv_gY9YjfhBnFumVsF8-n9XsFHoU69lo34&usqp=CAU)

![image](![카카오 &#39;라이언&#39;, 알리바바와 손잡고 중국 간다](https://image.edaily.co.kr/images/Photo/files/NP/S/2020/12/PS20120400340.jpg))

